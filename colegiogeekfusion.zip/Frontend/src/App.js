import React, {useState, useEffect} from "react";
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";
import axios from 'axios';

import {getFromLocal} from './functions/localstorage'

// Administrador 
import Admin from "./Pages/AdminInicio";
// import RegistroGrupo from "./Pages/RegistroGrupo";
import VerGrupos from "./Pages/AdminGrupos";

//  Profesor
import Profesor from "./Pages/ProfesorInicio";
import Grupos from "./Pages/ProfesorGrupos";
import Perfil from "./Pages/ProfesorPerfil";
import Notas from "./Pages/ProfesorNotas";

// Estudiante
import EstudianteInforme from "./Pages/EstudianteInforme";
import EstudianteMaterias from "./Pages/EstudianteMaterias";
import EstudianteNotas from "./Pages/EstudianteNotas";
import PerfilEstudiante from "./Pages/PerfilEstudiante";
import EstudianteInicio from "./Pages/EstudianteInicio";

// Sing in - Sing Up
import SignIn from "./Pages/SignIn";
import SignUp from "./Pages/SignUp";
import PerfilAdministrado from "./Pages/PerfilAdministrador";

function App() {
  const checkAuthenticated = async () => {
    try {
      axios.post('http://localhost:5000/auth/verify',null,{headers: {jwt_token: getFromLocal('token') }})
      .then(res => {
        const parseRes = await res.json();
        
        parseRes === true ? setIsAuthenticated(true) : setIsAuthenticated(false);
      })
    } catch (e) {
      console.error(e.message);
    }
  }
  
  useEffect(() => {
    checkAuthenticated();
  }, []);
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  let rol = 0;
  
  const setAuth = (boolean,r) => {
    setIsAuthenticated(boolean);
    rol = r;
  };
  
  const a = isAuthenticated && rol === 1;
  const p = isAuthenticated && rol === 2;
  const e = isAuthenticated && rol === 3;
  
  
  
  return (
    <BrowserRouter>
      <Switch>
        {/* Rutas Estudiante */}
        <Route exact path="/estudiante" render={
          props => {
                isAuthenticated ? (
                  <EstudianteInicio {...props} setAuth={setAuth} />
                ) : (
                  <Redirect to="/" /> 
                  )}} />
        <Route exact path="/estudiante-informe/:id">
        <EstudianteInforme {...props} setAuth={setAuth} />
        </Route>
        <Route exact path="/estudiante-materia/:id" >
        <EstudianteMaterias {...props} setAuth={setAuth} />
        </Route>
        <Route exact path="/estudiante-nota/:id" >
        <EstudianteNotas {...props} setAuth={setAuth} />
        </Route>
        <Route exact path="/estudiante-perfil/:id" >
        <PerfilEstudiante {...props} setAuth={setAuth} />
        </Route>

        {/* Rutas profesor */}
        <Route exact path="/profesor" render={
          props => {
                isAuthenticated ? (
                  <Profesor {...props} setAuth={setAuth} />
                ) : (
                  <Redirect to="/" /> 
                  )}} />
        <Route exact path="/profesor-grupos/:id" >
        <Grupos {...props} setAuth={setAuth} />
        </Route>
        <Route exact path="/profesor-perfil/:id" >
        <Perfil {...props} setAuth={setAuth} />
        </Route>
        <Route exact path="/profesor-notas/:id/:id_grupo/:cod_grupo" >
        <Notas {...props} setAuth={setAuth} />
        </Route>

        {/* Rutas Sign SignIn*/}
        <Route exact path="/" render={
          props =>
            !isAuthenticated ? (
              <SignIn {...props} setAuth={setAuth} />
            ) : a ? (
              <Redirect to="/administrador" />
            ) : p ? (
               <Redirect to="/profesor" />
            ) : (
                <Redirect to="/estudiante" />
           )
        } />

        {/* Rutas Admin */}
        <Route exact path="/administrador"render={
          props => {
                isAuthenticated ? (
                  <Admin {...props} setAuth={setAuth} />
                ) : (
                  <Redirect to="/" /> 
                  )}} />
        <Route exact path="/administrador-grupo" >
        <VerGrupos {...props} setAuth={setAuth} />
        </Route>
        {/* <Route exact path="/administrador-grupo" component={RegistroGrupos} /> */}
        <Route exact path="/administrador-perfil/:id">
        <PerfilAdministrado {...props} setAuth={setAuth} />
        </Route>
        <Route exact path="/administrador-usuario" component={SignUp} >
        <SignUp {...props} setAuth={setAuth} />
        </Route>
      </Switch>
    </BrowserRouter>
  );
}

export default App;
