import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import "./Css/styles.css"
//Bootstrap
import 'bootstrap/dist/css/bootstrap.min.css';
//JQuery
import 'bootstrap/dist/js/bootstrap.bundle.min';
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" ></script>

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

