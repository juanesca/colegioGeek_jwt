import React,{useState, useEffect} from "react";
import { Container, Row, Col, Image } from "react-bootstrap";
import { getFromLocal } from "../functions/localstorage";
import Quote from "./Quote";
import niño from "../Images/estudiante-nino.jpg";
import niña from "../Images/estudiante-nina.jpg";
import profe from "../Images/Profesor.jpg";
import admin from "../Images/Admin.jpg"

import axios from 'axios';


function BienvennidaE({setAuth}) {
/*  const nombre = getFromLocal("nombre_completo");
  const genero = getFromLocal("genero");
  const rol = getFromLocal("rol");
*/

const [name, setName] = useState("");
const [genero, setGenero] = useState("");
const [rol, setRol] = useState("");

const getProfile = async () => {
  try {
    axios.post('http://localhost:5000/',null,{headers: {jwt_token: getFromLocal('token')}})
    .then(res => {
      const parseData = await res.json();
      setName(parseData.nombre_completo);
      setRol(parseData.rol);
      setGenero(parseData.genero);
    })
  } catch (e) {
    console.error(e.message);
  }
}

const []
  return (
    <Container>
      <div className="text-center">
        {genero === "Hombre" ? (
          <h1 className="d-flex justify-content-center mt-5 mb-5">
            {" "}
            Bienvenido {name}!
          </h1>
        ) : (
          <h1 className="d-flex justify-content-center mt-5 mb-5">
            {" "}
            Bienvenida {name}!
          </h1>
        )}
      </div>
      <Row className="col-12 m-auto">
        <Col xs={12} md={6} className="p-0  ">
          {rol === "1" ? (
            <Image src={admin} thumbnail style={{ width: "50rem" }} />
          ) : rol === "2" ? (
            <Image src={profe} thumbnail style={{ width: "50rem" }} />
          ) : rol === "3" && genero === "Hombre" ? (
            <Image src={niño} thumbnail style={{ width: "50rem" }} />
          ) : rol === "3" && genero === "Mujer" ? (
            <Image src={niña} thumbnail style={{ width: "50rem" }} />
          ) : null}
        </Col>
        <Col xs={12} md={6} className="d-flex align-items-center pl-5 mt-4">
          <Quote />
        </Col>
      </Row>
    </Container>
  );
}

export default BienvennidaE;
