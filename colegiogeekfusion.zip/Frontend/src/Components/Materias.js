import React, { Component } from "react";
import MenuAdmin from "./menuAdmin";

class Materias extends Component {
    
    render() {

        return (
            <div className="">
                <MenuAdmin />

                <h1 className="ml-5 pl-5 pt-5">Listado de materias</h1>
                <div className="card col-10 row mx-auto mt-5">
                    
                </div>
            </div>
        );
    }
}

export default Materias;