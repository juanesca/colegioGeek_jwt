import React from "react";

function FooterEspecifico() {
  return (
    <div className="pl-3 pr-3 pt-3 mt-5 ml-5 mr-5 row d-flex align-items-center justify-content-center text-black">
      <h6>Colegio Geek | Registro y Control</h6> 
    </div>
  );
}

export default FooterEspecifico;
