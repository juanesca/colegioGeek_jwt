import React from "react";
import BienvennidaE from "../Components/BienvenidaE";
import MenuEstudiante from "../Components/menuEstudiante";

function EstudianteInicio({setAuth}) {
  return (
    <>
      <MenuEstudiante {...props} setAuth={setAuth}/>
      <BienvennidaE {...props} setAuth={setAuth}/>
    </>
  );
}

export default EstudianteInicio;
