import React from 'react';
import MenuAdmin from '../Components/menuAdmin';
import FormularioAdmin from '../Components/FormularioAdmin';

function SingUp({setAuth}) {
    return (
        <div>
            <MenuAdmin {...props} setAuth={setAuth} />
            <FormularioAdmin/>
        </div>
    );
}

export default SingUp;