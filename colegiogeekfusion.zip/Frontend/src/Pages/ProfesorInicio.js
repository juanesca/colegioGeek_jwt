import React from 'react';
import MenuProfesor from '../Components/menuProfesor';
// import Contenido from '../Components/contenido';
import BienvennidaE from '../Components/BienvenidaE';

function Profesor({setAuth}) {
    return (
        <div>
            <MenuProfesor {...props} setAuth={setAuth}/>
            <BienvennidaE {...props} setAuth={setAuth}/>
        </div>
    );
}

export default Profesor;
