import React from 'react';
import {  Container } from "react-bootstrap";
import MenuProfesor from '../Components/menuProfesor';
import ProfesorPerfil from '../Components/perfil';

function Perfil({setAuth}) {
    return (
        <div>
            <MenuProfesor {...props} setAuth={setAuth} />
            <Container className="mt-5 d-flex justify-content-center">
            <ProfesorPerfil/>
            </Container>
        </div>
    );
}

export default Perfil;