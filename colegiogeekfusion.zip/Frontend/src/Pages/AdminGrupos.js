import React from "react";
import MenuAdmin from "../Components/menuAdmin";
import Grupo from "../Components/Grupo"

function AdminGrupos({setAuth}){
    return(
        <div>
            <MenuAdmin {...props} setAuth={setAuth}/>
            <Grupo />
        </div>
    )
}

export default AdminGrupos;