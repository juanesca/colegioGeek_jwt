import React from 'react';
import MenuAdmin from '../Components/menuAdmin';
import BienvennidaE from '../Components/BienvenidaE';

function AdminInicio({setAuth}) {
    return (
        <div className="Container">
            
            <MenuAdmin {...props} setAuth={setAuth}/>
            <BienvennidaE {...props} setAuth={setAuth} />
            
        </div>
    );
}

export default AdminInicio;