import React from 'react';
import MenuProfesor from '../Components/menuProfesor';
import TablaGrados from '../Components/tablaGrados';

function Grupos({setAuth}) {
    return (
        <div>
            <MenuProfesor {...props} setAuth={setAuth} />
            <TablaGrados />
        </div>
    );
}

export default Grupos;