import React from 'react';
import MenuProfesor from '../Components/menuProfesor';
import Profesor from '../Components/profesor';
// import TablaNotas from '../Components/tablaNotas';
import TablaNotas from '../Components/tablaNotas';


function Notas({setAuth}) {
    return (
        <div>
            <MenuProfesor {...props} setAuth={setAuth} />
            <Profesor />
            <TablaNotas />
        </div>
    );
}

export default Notas;