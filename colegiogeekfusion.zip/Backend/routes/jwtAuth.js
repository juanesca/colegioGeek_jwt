const router = require("express").Router();
const { cnn_postgreSQL } = require("../DB/conexion");
const { encryptPassword, matchPassword } = require("../lib/helpers");
const jwtGenerator = require("../lib/jwtGenerator");
const authorize = require("../lib/authorize");

router.post("/signup", async (req, res) => {
  const {
    doctype,
    docnum,
    name,
    genero,
    nacimiento,
    direccion,
    ciudad,
    telefono,
    celular,
    email,
    password,
    picked,
  } = req.body;

  try {
    const user = await cnn_postgreSQL.query(
      "SELECT * FROM usuario WHERE correo = $1",
      [email]
    );

    if (user.rows.length > 0) {
      return res.status(401).json("El usuario ya existe");
    }

    const encryptedPass = await encryptPassword(password);

    let newUser = await cnn_postgreSQL.query("INSERT INTO usuario (tipo_documento,documento,nombre_completo,genero,fecha_nacimiento,direccion,ciudad telefono,celular,correo,contraseña,rol) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)", [
      doctype,
      docnum,
      name,
      genero,
      nacimiento,
      direccion,
      ciudad,
      telefono,
      celular,
      email,
      encryptedPass,
      picked,
    ]);
/*
    const jwtToken = jwtGenerator(newUser.rows[0].id_usuario);
*/
    return res.json("ok");
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

router.post("/login", async (req, res) => {
  const { correo, contrasena, rol } = req.body;
  console.log(req.body);

  try {
    const user = await cnn_postgreSQL.query(
      `SELECT * FROM usuario WHERE correo='${correo}' AND rol='${rol}';`
    );

    if (user.rows.length === 0) {
      return res.status(401).json("Invalid Credential");
    }

    const validPassword = await matchPassword(
      contrasena,
      user.rows[0].contrasena
    );

    if (!validPassword) {
      return res.status(401).json("Invalid Credential");
    }

    const jwtToken = jwtGenerator(user.rows[0].id_usuario);
    return res.json({ jwtToken });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

router.post("/verify", authorize, (req, res) => {
  try {
    res.json(true);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

module.exports = router;
