//descripción de lo que voy hacer 

describe("prueba", ()=>{
    it("verificar que 1 es igual a 1", () => {
        expect(1).toBe(1)
    })
})