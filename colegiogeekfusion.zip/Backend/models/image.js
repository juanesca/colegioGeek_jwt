module.export = function (cnn_postgreSQL, DataTypes) {
    let Image = cnn_postgreSQL.define("photo", {
        image_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        image: {
            type: DataTypes.STRING,
            allowNull: false
        }
    });
    let Pdf = cnn_postgreSQL.define("pdf", {
        pdf_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        pdf: {
            type: DataTypes.STRING,
            allowNull: false
        }
    });

    return Image, Pdf
} 




// const express = require('express');
// const router = express.Router();
// const multer = require('multer')
// const path = require('path');

// const storage = multer.diskStorage({
//     destination: path.join(__dirname, '../public/uploads'),
//     filename: (req, file, cb) => {
//         cb(null, file.originalname);
//     }
// });

// const cargarImagen = multer({
//     storage,
//     limits: { fileSize: 1000000 }
// }).single('image');

// //Middleware
// router.post('/images/upload', (req, res) => {
//     cargarImagen(req, res, (err) => {
//         if (err) {
//             err.message = 'Error al cargar imagen';
//             return res.send(err);
//         }

//         console.log(req.file);
//         res.send('Imagen ok!');
//     })

// });

// module.exports = router;